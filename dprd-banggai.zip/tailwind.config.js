module.exports = {
	content: ["./application/views/**/*.{html,js,php}"],
	theme: {
		extend: {
			colors: {
				'primary': '#FE0B3C',
			}
		}
	}
}
