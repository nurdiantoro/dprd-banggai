<section id="e-aspirasi">
    <div class="container text-center">
        <h2 class="text-center warna-01">KAMU PUNYA MASUKAN?</h2>
        <p>Masukan kamu akan sangat membantu. Silahkan klik tombol di bawah ini</p>
        <a href="<?= base_url('tentang#e-aspirasi') ?>" class="btn-e-aspirasi">e-Aspirasi</a>
    </div>
</section>